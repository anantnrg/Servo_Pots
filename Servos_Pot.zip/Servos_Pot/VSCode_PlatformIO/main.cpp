//Coded by Anant Narayan for controlling multiple servo with multiple potentiometers
//Hosted on Github by Anant Narayan
//This code is in the public domain

#include <Arduino.h>
#include <Servo.h>

Servo myservo1;
Servo myservo2;

int potpin = 0;
int potpin1 = 2;


int val = 0;
int val1 = 0;


void setup()
{

myservo1.attach(3);
myservo2.attach(5);


}

void loop()
{

val = analogRead(potpin);
val = map(val, 3, 1023, 0, 176);

myservo1.write(val);

delay(25);

val1 = analogRead(potpin1);
val1 = map(val1, 3, 1023, 0, 176);

myservo2.write(val1);

delay(25);


}